package com.valdoria.zumbi;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.entity.ZombieRenderer;

/** Reaproveita a aparência e animações vanilla do zumbi. */
public final class ValdoriaZumbiClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ValdoriaZumbiMod.ZOMBIE_TYPE, ZombieRenderer::new);
    }
}
