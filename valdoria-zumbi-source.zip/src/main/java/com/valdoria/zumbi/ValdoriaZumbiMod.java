package com.valdoria.zumbi;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.phys.Vec3;

/**
 * Valdoria - Zumbi no Pacífico (Fabric 26.3).
 *
 * Nenhum spawn natural ou dificuldade global é alterado.
 * A única entidade especial é valdoria_zumbi:zumbi, criada por /zumbi.
 */
public final class ValdoriaZumbiMod implements ModInitializer {
    public static final String MOD_ID = "valdoria_zumbi";

    private static final Identifier ZOMBIE_ID = Identifier.fromNamespaceAndPath(MOD_ID, "zumbi");
    private static final ResourceKey<EntityType<?>> ZOMBIE_KEY = ResourceKey.create(Registries.ENTITY_TYPE, ZOMBIE_ID);

    /* Por padrão o Builder permite a entidade no Pacífico. Não usar .notInPeaceful().
       Não há SpawnPlacements nem biome modifications; assim não nasce naturalmente. */
    public static final EntityType<ValdoriaZombie> ZOMBIE_TYPE = Registry.register(
        BuiltInRegistries.ENTITY_TYPE,
        ZOMBIE_KEY,
        EntityType.Builder.<ValdoriaZombie>of(ValdoriaZombie::new, MobCategory.MONSTER)
            .sized(0.6F, 1.95F)
            .clientTrackingRange(8)
            .build(ZOMBIE_KEY)
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(ZOMBIE_TYPE, Zombie.createAttributes());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("zumbi")
                .requires(source -> source.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
                .executes(context -> spawn(context.getSource()))
                .then(Commands.literal("limpar")
                    .executes(context -> clear(context.getSource())))
                .then(Commands.literal("contar")
                    .executes(context -> count(context.getSource()))));
        });
    }

    private static int spawn(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = source.getLevel();
        Vec3 look = player.getLookAngle();
        Vec3 where = player.position().add(look.x * 3.0, 0.0, look.z * 3.0);

        ValdoriaZombie zombie = new ValdoriaZombie(ZOMBIE_TYPE, level);
        zombie.setPos(where.x, where.y, where.z);
        zombie.setPersistenceRequired();
        zombie.addTag("valdoria_zumbi_invocado");
        zombie.setCanBreakDoors(false); // não danificar as casas e farms com arrombamento

        if (!level.addFreshEntity(zombie)) {
            source.sendFailure(Component.literal("[Valdoria] Não foi possível invocar o zumbi neste local."));
            return 0;
        }
        source.sendSuccess(() -> Component.literal("[Valdoria] Zumbi agressivo invocado!"), false);
        return 1;
    }

    /** Apenas entidades carregadas: chunks descarregados não estão na lista do servidor. */
    private static int clear(CommandSourceStack source) {
        int removed = 0;
        MinecraftServer server = source.getServer();
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof ValdoriaZombie zombie && zombie.isAlive()) {
                    zombie.discard();
                    removed++;
                }
            }
        }
        final int total = removed;
        source.sendSuccess(() -> Component.literal("[Valdoria] Zumbis especiais removidos: " + total + " (chunks carregados)."), false);
        return total;
    }

    private static int count(CommandSourceStack source) {
        int active = 0;
        for (ServerLevel level : source.getServer().getAllLevels()) {
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof ValdoriaZombie zombie && zombie.isAlive()) active++;
            }
        }
        final int total = active;
        source.sendSuccess(() -> Component.literal("[Valdoria] Zumbis especiais vivos e carregados: " + total), false);
        return total;
    }
}
