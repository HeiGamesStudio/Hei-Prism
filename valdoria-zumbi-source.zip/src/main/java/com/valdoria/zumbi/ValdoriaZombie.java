package com.valdoria.zumbi;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.level.Level;

/** Zumbi real (subclasse do vanilla), mas registrado num tipo isolado. */
public final class ValdoriaZombie extends Zombie {
    private static final double SEARCH_DISTANCE = 28.0;
    private static final double ATTACK_DISTANCE_SQUARED = 2.5 * 2.5;
    private static final float ATTACK_DAMAGE = 3.0F; // 1,5 corações antes da armadura

    public ValdoriaZombie(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
    }

    /**
     * Sem as metas vanilla que perseguem aldeões/golens.
     * A perseguição ao jogador é controlada abaixo sem modificar os mobs normais.
     */
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    /** Impede o descarte por Pacífico ou por afastamento, apenas para este tipo. */
    @Override
    public void checkDespawn() {
        // Intencional: a entidade já é criada somente por comando e fica persistente.
    }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel level) || !isAlive()) return;
        if (tickCount % 5 != 0) return;

        ServerPlayer player = (ServerPlayer) level.getNearestPlayer(
            getX(), getY(), getZ(), SEARCH_DISTANCE,
            candidate -> candidate instanceof ServerPlayer p &&
                p.isAlive() && !p.isCreative() && !p.isSpectator());

        if (player == null) {
            setAggressive(false);
            // Não perseguir criativos nem espectadores.
            return;
        }

        setAggressive(true);
        getLookControl().setLookAt(player, 30.0F, 30.0F);

        // No Pacífico a IA vanilla não considera jogadores alvos válidos.
        // A navegação é solicitada diretamente somente para este zumbi.
        if (tickCount % 10 == 0) {
            getNavigation().moveTo(player, 1.15D);
        }

        if (tickCount % 20 == 0
            && distanceToSqr(player) <= ATTACK_DISTANCE_SQUARED
            && hasLineOfSight(player)) {
            swing(InteractionHand.MAIN_HAND);

            // O dano padrão mobAttack é zerado no Pacífico.
            // generic() não recebe a redução de dificuldade; armadura ainda funciona.
            player.hurtServer(level, level.damageSources().generic(), ATTACK_DAMAGE);
        }
    }
}
